package com.cg.employeeapp.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="employees")
public class Employee {
	
	@Id
	private int id;
	@NotEmpty(message="Employee name is Mandatory")
	@Pattern(regexp="[A-Za-z\\s]+",message="Name should contain only alphabets")
	private String name;
	private String gender;
	@Max(60)
	@Min(18)
	/*@NotEmpty(message="Employee age is Mandatory")*/
	private int age;
	/*@Pattern(regexp="[0-9]{1,}",message="Salary should be a number")*/
	private double salary;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	

}
