package com.capg.employee.service;

import java.util.List;

import com.capg.employee.dao.EmployeeDao;
import com.capg.employee.dao.EmployeeDaoImpl;
import com.capg.employee.dto.Employee;
import com.capg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDao employeeDao=new EmployeeDaoImpl();

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		return employeeDao.getEmployees();
	}

}
