package com.capg.employee.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capg.employee.dto.Employee;
import com.capg.employee.exception.EmployeeException;
import com.capg.employee.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public List<Employee> getEmployees() throws EmployeeException {
		Connection con=DBUtil.getConnection();
		List<Employee> employees=new ArrayList<Employee>();
		try {
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery("SELECT * FROM EMPLOYEES");
			while(rs.next()){
				Employee emp=new Employee();
				emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setGender(rs.getString(3));
				emp.setAge(rs.getInt(4));
				emp.setSalary(rs.getDouble(5));
				employees.add(emp);
			}
			return employees;
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}
	}

}
