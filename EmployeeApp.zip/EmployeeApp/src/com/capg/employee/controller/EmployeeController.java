package com.capg.employee.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.employee.dto.Employee;
import com.capg.employee.exception.EmployeeException;
import com.capg.employee.service.EmployeeService;
import com.capg.employee.service.EmployeeServiceImpl;


@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeService service=new EmployeeServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			List<Employee> employees=service.getEmployees();
			RequestDispatcher rd=request.getRequestDispatcher("SuccessServlet");
			request.setAttribute("employees",employees);
			rd.forward(request, response);
		} catch (EmployeeException e) {
			RequestDispatcher rd=request.getRequestDispatcher("ErrorServlet");
			request.setAttribute("error", e);
			rd.forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
