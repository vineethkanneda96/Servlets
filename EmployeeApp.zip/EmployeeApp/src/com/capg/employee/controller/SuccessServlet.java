package com.capg.employee.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.employee.dto.Employee;

@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		List<Employee> employees=(List<Employee>) request.getAttribute("employees");
		out.println("<table border='1'>");
		out.println("<tr>");
		out.println("<th>Employee Id</th><th>Employee Name</th>");
		out.println("<th>Gender</th><th>Age</th><th>Salary</th></tr>");
		for (Employee employee : employees) {
			out.println("<tr>");
			out.println("<td>"+employee.getId()+"</td>");
			out.println("<td>"+employee.getName()+"</td>");
			out.println("<td>"+employee.getGender()+"</td>");
			out.println("<td>"+employee.getAge()+"</td>");
			out.println("<td>"+employee.getSalary()+"</td></tr>");
		}
		out.println("</table>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
