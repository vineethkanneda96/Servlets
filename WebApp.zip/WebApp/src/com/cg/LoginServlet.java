package com.cg;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/LoginServlet",initParams={@WebInitParam(name="user",value="vineeth"),
		   @WebInitParam(name="password",value="asdfgh@123")}
           )
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("pass");
		String u=getServletConfig().getInitParameter("user");
		String p=getServletConfig().getInitParameter("password");
		if(username.equals(u)&&password.equals(p)){
			//response.sendRedirect("success.html"); page name is displayed in the url
			
			/*or while using like this in url mapping we have to mention / or else it wont run the page
			 * ServletContext context=getServletContext();
			RequestDispatcher rd1=context.getRequestDispatcher("/success.html");*/
			
			RequestDispatcher rd=request.getRequestDispatcher("success.html");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("error.html");
			rd.forward(request, response);
		}
	}

}
