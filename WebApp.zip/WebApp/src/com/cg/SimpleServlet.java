package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        resp.setContentType("text/html");
	        PrintWriter out=resp.getWriter();
	        out.print("<h1>Welcome to servlets</h1>");
	        ServletConfig config=getServletConfig();
	        String name=config.getInitParameter("myname");
	        String city=config.getInitParameter("city");
	        out.print("Hello "+name);
	        out.print("<br>You are from "+city);
	        ServletContext context=getServletContext();
	        out.print("<br><h2> Parameter 1="+context.getInitParameter("parameter"));
	        out.print("<br> Parameter 2="+context.getInitParameter("parameter2")+"</h2>");
	}
}
