package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
//initialization while using annotations
@WebServlet(urlPatterns={"/MyServlet","/Hello"},
initParams={@WebInitParam(name="user",value="vineeth"),
@WebInitParam(name="company",value="capgemini")		
},loadOnStartup=1)
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ServletConfig config=getServletConfig();
		out.print("<html><body><font color=green>");
		out.print("Hi "+config.getInitParameter("user")+" You are working in "+config.getInitParameter("company"));
		ServletContext context=getServletContext();
        out.print("</font><br><font color=red><h2> Parameter 1="+context.getInitParameter("parameter"));
        out.print("<br> Parameter 2="+context.getInitParameter("parameter2"));
        out.print("<br> Parameter 3="+context.getInitParameter("param3"));
        out.print("<br> Parameter 4="+context.getInitParameter("param4")+"</h2></font>");
		out.print("</body></html>");
	}

}
