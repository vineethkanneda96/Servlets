package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//session tracking concepts
@WebServlet(urlPatterns="/SuccessServlet",initParams={@WebInitParam(name="user",value="vineeth"),
		   @WebInitParam(name="password",value="asdf")}
        )
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("username");
		String password=request.getParameter("pass");
		String u=getServletConfig().getInitParameter("user");
		String p=getServletConfig().getInitParameter("password");
		if(username.equals(u)&&password.equals(p)){
			out.print("<h1>Welcome "+username);
			/*out.print("<form method='post' action='GreetServlet'>");
			//out.print("<input type='hidden' value='"+username+"' name='user'/>"); hidden form fields method
			out.print("<input type='submit' value='Greet'/>");
			out.print("</form>");*/
			out.print("<br><a href='GreetServlet?user="+username+"'><button>Greet</button></a>"); // if we want button instead of link
			//or
			//out.print("<br><a href='GreetServlet?user="+username+"'>Greet</a>");
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("error.html");
			rd.forward(request, response);
		}
	}
	
}


